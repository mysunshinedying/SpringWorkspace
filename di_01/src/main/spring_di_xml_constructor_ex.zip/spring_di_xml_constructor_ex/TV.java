package com.di.spring_di_xml_constructor_ex;

public class TV {
	Speaker speakerVolume;
	
	public TV(Speaker speakerVolume) {
		this.speakerVolume = speakerVolume;
	}
	
    public void volumeUp() {
    	speakerVolume.volumeUp();
    }
    public void volumeDown() {
    	speakerVolume.volumeDown();
    }
}
