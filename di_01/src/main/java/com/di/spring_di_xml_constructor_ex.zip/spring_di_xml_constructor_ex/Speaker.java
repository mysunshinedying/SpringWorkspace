package com.di.spring_di_xml_constructor_ex;

public class Speaker {
	public String volumeUp() {
		String msg = "볼륨을 키웁니다.";
		return msg;
	}
	
	public String volumeDown() {
		String msg = "볼륨을 낮춥니다.";
		return msg;
		
	}
}
